# Failure-mode report

- **Task**: `M163/sub_address_conditional`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:subscribed_to_work`  —  1/1 (100%)

- **dominant failure_class**: `subscription_not_created`  (breakdown: {'subscription_not_created': 1})
- **missed required milestones**: ['subscribed_to_work']
- **app path**: shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `956e377a` (seed 2, stalled at step 0, 11 steps)
