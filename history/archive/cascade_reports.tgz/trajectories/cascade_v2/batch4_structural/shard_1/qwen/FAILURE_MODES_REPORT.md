# Failure-mode report

- **Task**: `M161/refund_method_conditional_on_amount`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:returned_store_credit`  —  1/1 (100%)

- **dominant failure_class**: `return_not_initiated`  (breakdown: {'return_not_initiated': 1})
- **missed required milestones**: ['returned_store_credit']
- **app path**: shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `8f6fdb88` (seed 2, stalled at step 0, 35 steps)
