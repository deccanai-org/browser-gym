# Failure-mode report

- **Task**: `M116/inbox_says_cancelled_live_says_active`
- **Model**: `gpt-5.5`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:verified_live_order`  —  1/1 (100%)

- **dominant failure_class**: `unclassified_failure`  (breakdown: {'unclassified_failure': 1})
- **missed required milestones**: ['verified_live_order']
- **app path**: mail -> shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `a0046e30` (seed 2, stalled at step 0, 9 steps)
