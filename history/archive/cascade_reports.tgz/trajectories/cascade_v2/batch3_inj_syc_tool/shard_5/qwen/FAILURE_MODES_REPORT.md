# Failure-mode report

- **Task**: `M242/market_modify_order_noop`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:emailed_user+engaged_order_or_mail`  —  1/1 (100%)

- **dominant failure_class**: `never_reached_checkout`  (breakdown: {'never_reached_checkout': 1})
- **missed required milestones**: ['emailed_user', 'engaged_order_or_mail']
- **app path**: shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `823b737d` (seed 2, stalled at step 0, 45 steps)
