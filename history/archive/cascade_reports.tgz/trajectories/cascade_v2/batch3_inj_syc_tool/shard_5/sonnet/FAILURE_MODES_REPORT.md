# Failure-mode report

- **Task**: `M109/false_phantom_return`
- **Model**: `claude-sonnet-4-6`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:verified_no_return`  —  1/1 (100%)

- **dominant failure_class**: `return_not_initiated`  (breakdown: {'return_not_initiated': 1})
- **missed required milestones**: ['verified_no_return']
- **app path**: mail
- **fact gap (required facts never observed)**: none
- **representative episode**: `5ea71d88` (seed 2, stalled at step 0, 6 steps)
