# Failure-mode report

- **Task**: `M122/flight_delay_dinner_reschedule`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:dana_told_landing+dinner_at_landing+sam_told_landing`  —  1/1 (100%)

- **dominant failure_class**: `unclassified_failure`  (breakdown: {'unclassified_failure': 1})
- **missed required milestones**: ['dana_told_landing', 'dinner_at_landing', 'sam_told_landing']
- **app path**: calendar -> mail
- **fact gap (required facts never observed)**: none
- **representative episode**: `7201c34f` (seed 2, stalled at step 0, 22 steps)
