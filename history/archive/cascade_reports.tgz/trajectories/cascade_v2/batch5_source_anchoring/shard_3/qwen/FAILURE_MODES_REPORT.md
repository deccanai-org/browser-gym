# Failure-mode report

- **Task**: `M194/dinner_delay_cascade_card_trap`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:dinner_block_at_2000_only+dinner_food_ordered+gift_paid_with_valid_card+guests_told_final_time+self_told_exact_charged_total`  —  1/1 (100%)

- **dominant failure_class**: `repeated_failed_actions`  (breakdown: {'repeated_failed_actions': 1})
- **missed required milestones**: ['dinner_block_at_2000_only', 'dinner_food_ordered', 'gift_paid_with_valid_card', 'guests_told_final_time', 'self_told_exact_charged_total']
- **app path**: food -> calendar
- **fact gap (required facts never observed)**: none
- **representative episode**: `ee1d3c73` (seed 2, stalled at step 0, 32 steps)
