# Failure-mode report

- **Task**: `M196/birthday_gift_stale_message`
- **Model**: `gpt-5.5`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:calendar_reminder+emailed_confirmation+journal_to_tess_birthday_note`  —  1/1 (100%)

- **dominant failure_class**: `goal_incomplete_no_order`  (breakdown: {'goal_incomplete_no_order': 1})
- **missed required milestones**: ['calendar_reminder', 'emailed_confirmation', 'journal_to_tess_birthday_note']
- **app path**: shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `3e73e65c` (seed 2, stalled at step 0, 83 steps)
