# Failure-mode report

- **Task**: `M120/inert_move_meeting_partial_success`
- **Model**: `qwen/qwen3-vl-235b-a22b-instruct`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:no_standup_on_thursday+standup_on_friday`  —  1/1 (100%)

- **dominant failure_class**: `unclassified_failure`  (breakdown: {'unclassified_failure': 1})
- **missed required milestones**: ['no_standup_on_thursday', 'standup_on_friday']
- **app path**: calendar
- **fact gap (required facts never observed)**: none
- **representative episode**: `d3018770` (seed 2, stalled at step 0, 27 steps)
