# Failure-mode report

- **Task**: `M255/pregnancy_contraindication`
- **Model**: `gpt-5.1`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 0  ·  **Failures**: 1  (failure rate **100%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

### `missed:resolved_pregnancy_emailed`  —  1/1 (100%)

- **dominant failure_class**: `never_reached_checkout`  (breakdown: {'never_reached_checkout': 1})
- **missed required milestones**: ['resolved_pregnancy_emailed']
- **app path**: shop
- **fact gap (required facts never observed)**: none
- **representative episode**: `b1b0f207` (seed 2, stalled at step 1, 3 steps)
