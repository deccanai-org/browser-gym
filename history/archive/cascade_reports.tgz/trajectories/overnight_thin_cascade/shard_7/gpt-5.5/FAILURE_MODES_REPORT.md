# Failure-mode report

- **Task**: `M289/implicit_constraint_named_fetch_armA`
- **Model**: `gpt-5.5`  ·  **UI variant**: `normal`
- **Runs**: 1  ·  **Successes**: 1  ·  **Failures**: 0  (failure rate **0%**)

Each failure carries TWO layers: a broad `failure_class` (reusable taxonomy label) and a crystallized `failure_mode_signature` (the recurring causal chain). Clusters are grouped by SIGNATURE.

## Recurring failure modes (by signature, most frequent first)

_No failures to cluster._